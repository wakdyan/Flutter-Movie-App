var scoreList = ['3210', '1232', '44'];
var labelList = ['Like', 'Watching', 'Comments'];
