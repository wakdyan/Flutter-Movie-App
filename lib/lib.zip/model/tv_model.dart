class Tv {
  int id;
  String title, overview, releaseDate, posterPath;

  Tv(this.title, this.overview, this.releaseDate, this.posterPath, this.id);

  factory Tv.fromJson(Map<String, dynamic> json) {
    return Tv(
        json['name'],
        json['overview'],
        json['release_date'],
        json['poster_path'],
        json['id']
    );
  }
}