class Movies {
  int id;
  String title, overview, releaseDate, posterPath;

  Movies(this.title, this.overview, this.releaseDate, this.posterPath, this.id);

  factory Movies.fromJson(Map<String, dynamic> json) {
    return Movies(
        json['title'],
        json['overview'],
        json['release_date'],
        json['poster_path'],
        json['id']
    );
  }
}